# -*- coding: utf-8 -*-
# @Time : 2023/10/19 10:37
# @Author : ltm
# @Email :
# @Desc :

import dotenv
import os

if os.path.exists('../.env'):
    dotenv.load_dotenv('../.env')

from src.core.presido import pii_engine, AnalyzeResult, OperatorConf, CustomAnalyzeModel


if __name__ == '__main__':
    lang = 'zh'

    supported_entities = pii_engine.get_supported_entities(lang)
    print(supported_entities)

    text = '我叫李雷，性别男，家住北京市朝阳区光华路7号汉威大厦，电子邮箱为tangxin@ciic.com.cn，我的身份证号码是411323198303155953，我的的电话号码是13122832932'

    # 动态实体处理方案
    entity_operator_mapping = {
        "PERSON": "[姓名]",
        "ID_CARD": "[证件号码]",
        "PHONE_NUMBER": "[手机号码]",
        "EMAIL_ADDRESS": "[电子邮箱]"
    }

    # 步骤1：从映射字典直接获取实体列表，确保完全同步
    entities_to_process = list(entity_operator_mapping.keys())

    # 使用analyze方法一次性识别所有需要处理的实体
    analyze_results = pii_engine.analyze(
        text=text,
        entities=entities_to_process,  # 动态使用映射中的键
        language=lang,
        score_threshold=0.3
    )
    print(f"识别结果: {analyze_results}")

    # 步骤2：自动构建分析结果和操作配置
    analyzer_result_list = []
    operator_conf_list = []

    # 按起始位置降序排序（关键：解决替换时的位置偏移问题）
    sorted_results = sorted(analyze_results, key=lambda x: x['start'], reverse=True)

    for result in sorted_results:
        entity_type = result['entity_type']

        # 仅处理配置了映射的实体
        if entity_type in entity_operator_mapping:
            # 自动添加实体识别结果
            analyzer_result_list.append(
                AnalyzeResult(
                    entity_type=entity_type,
                    start=result['start'],
                    end=result['end'],
                    score=result['score']
                )
            )

            # 自动添加对应的操作配置
            operator_conf_list.append(
                OperatorConf(
                    entity_type=entity_type,
                    operator_name="replace",
                    params={"new_value": entity_operator_mapping[entity_type]}
                )
            )

    # 步骤3：单次调用完成所有脱敏操作
    final_result = pii_engine.anonymize(
        text=text,
        analyzer_results=analyzer_result_list,
        llm_synthesize=False,
        operators=operator_conf_list
    )

    print(f"最终脱敏结果: {final_result}")

    # （可选）获取完整支持的实体类型
    all_supported_entities = pii_engine.get_supported_entities(lang)
    print(f"系统支持的全部实体类型: {all_supported_entities}")
